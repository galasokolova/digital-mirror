package org.example.digitalmirror.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.ClassPathResource;

import static org.junit.jupiter.api.Assertions.*;

class ClaimServiceTest {
    private ClaimService createService() {
        return new ClaimService(new ObjectMapper(), new ClassPathResource("data/claims.json"));
    }

    @Test
    void shouldCycleThroughClaims() {
        ClaimService service = createService();
        assertEquals("demo-001", service.getNextClaim().id());
        assertEquals("demo-002", service.getNextClaim().id());
        assertEquals("demo-003", service.getNextClaim().id());
        assertEquals("demo-001", service.getNextClaim().id());
    }

    @Test
    void shouldFindClaimById() {
        ClaimService service = createService();
        assertEquals("SUPPORTS", service.findById("demo-002").orElseThrow().verifiedLabel());
        assertTrue(service.findById("missing").isEmpty());
    }
}
